#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "libprop.h"


int spectral(float *ampa, float *Twa, float Lwa, float h, int in, float lat, float *Cwa, float pi, float rho)
{
  FILE * fp;
  char name[FILENAME_MAX];
    float g=0, power=0, depthoint=0, mvvx=0, mvvy=0, a0=0, f=0, k=0, ka=0, ep1=0, ep2=0, ep3=0, b1=0, b2=0, b3=0, b4=0, kh=0, A1=0,A2=0,A3=0,A4=0, A5=0,B1=0,B2=0,B4=0,B6=0,B8=0,B10=0,B12=0,C1=0,C2=0,C3=0,C4=0,C5=0,E1=0,F1=0,F2=0,F3=0,F4=0,F5=0, G1=0,G2=0,G3=0,G4=0,G5=0,W1=0,W2=0,W3=0,W4=0,W5=0, kons=0, D1=0, Cl=0;
      fp = fopen("spectral.txt", "a");
      if(fp == NULL)
   {
      printf("Error could not open or create file!");
      exit(1);
   }
      g=pl_gravity(lat);
      f=(1/(*Twa));
      if (*Cwa==52){
          *ampa=*ampa/2;
      }
      power=((rho*g)/2)*(*ampa)*(*ampa);
      depthoint=Lwa/2;
      a0=(*ampa*2*pi)/(*Twa);
      k=(2*pi)/Lwa;
      kh=k*h;
      Cl=(Lwa/(*Twa));
      D1=(1/sinh(kh));

      if((*Cwa)==11)//Here we calculate the max induced velocities for 1st order deep water waves
      {
        mvvx=a0;
        mvvy=a0;
      }
      else if((*Cwa)==12)//Here we calculate the max induced velocities for 1st order transitional water waves
      {
        mvvx=fabs(a0*(cosh(-kh))/sinh(kh));
        mvvy=fabs(a0*(sinh(-kh))/sinh(kh));
      }
      else if((*Cwa)==21)//Here we calculate the max induced velocities for 2nd order deep water waves
      {
        mvvx=fabs((-a0*cosh(-kh)*(1/sinh(kh))));
        mvvy=fabs((-a0*sinh(-kh)*(1/sinh(kh))));
      }
      else if((*Cwa)==22)//Here we calculate the max induced velocities for 2nd order transitional water waves
      {
        mvvx= fabs((-a0/4)*(1/sinh(kh))*((4*cosh(-kh)) + ((3*(*ampa)*k*(cosh(-2*kh)))*(pow(1/sinh(kh),3)))));
        mvvy= (*ampa)*2*pi*f;

      }
      else if((*Cwa)==31)//Here we calculate the max induced velocities for 3rd order deep water waves
      {
        mvvx= (*ampa)*sqrt(g/k)*k;
        mvvy=mvvx;
      }
      else if((*Cwa)==32)//Here we calculate the max induced velocities for 3rd order transitional water waves
      {
        mvvx=fabs(-( ((((((9/(sinh(kh)*sinh(kh)))-4)*(1/sinh(kh))*((cosh(3*kh))*(*ampa)*k))+(16*cosh(2*kh)))*(3*(*ampa)*k*(1/pow(sinh(kh),3))))+64*cosh(kh)))*((((*ampa)*2*pi*f)/sinh(kh))/64));
        mvvy=fabs(-( ((((((9/(sinh(kh)*sinh(kh)))-4)*((sinh(3*kh))*(*ampa)*k)))*(3*(*ampa)*k*(1/pow(sinh(kh),3))))-(64*sinh(kh)))*((((*ampa)*2*pi*f)/sinh(kh))/64)));
      }
	else if((*Cwa)==41)//Here we calculate the max induced velocities for 4th order deep water waves 
      	{
        ka=k*(*ampa);
        kons=sqrt(g/k);
        ep1=-(Lwa/(*Twa));
        ep2=(-8-(4*pow(ka,2))-(pow(ka,4)));
        ep3=(2-pow(ka,2));
        b1=(-4*ka*(-2+pow(ka,2)));
        b2=(8*pow(ka,4));
        b3=(ka);
        b4=(4*pow(ka,3));
        mvvx=fabs(ep1-((kons/8)*(ep2+(b1*cos(0))+(b2*cos(0)))));    
	mvvy=fabs((kons/2)*b3*(ep3+(b4*cos(pi/2)))*sin(pi/2));
        }
	else if((*Cwa)==42)//Here we calculate the max induced velocities for 4th order transitonal water waves
        {
       ka=k*(*ampa);
        B1=cosh(kh);
        B2=cosh(2*kh);
        B4=cosh(4*kh);
        B6=cosh(6*kh);
        B8=cosh(8*kh);
        B10=cosh(10*kh);
        B12=cosh(12*kh);
        F1=sinh(kh);
        	F2=sinh(2*kh);
        	F3=sinh(3*kh);
        	F4=sinh(4*kh);
        	C1=cosh(kh);
        	C2=cosh(2*kh);
        C3=cosh(3*kh);
        C4=cosh(4*kh);
        A1=cos(pi);
        A2=cos(2*pi);
        A3=cos(3*pi);
        A4=cos(4*pi);
        G1=sin(pi/2);
        G2=sin(2*(pi/2));
        G3=sin(3*(pi/2)); 
        G4=sin(4*(pi/2));
        W1=-((pow(ka,4)*k*(197-(1338*pow(B1,2))+(736*pow(B1,6)))*pow(D1,10))/(6144*(2+(3*B2))));
        W2=(3/131072)*pow(ka,3)*k*pow(D1,7)*(2816-(512*B2)+((pow(ka,2)*(697-(2186*B2)-(5498*B4)-(3192*B6)+(367*B8)+(90*B10)+(2*B12))*pow(D1,6))/(8*(2+(3*B2)))));
        W3=(0.5)*pow(ka,2)*k*(((1/3)*pow(D1,4))+((pow(ka,2)*(104-(123*B2)-(306*B4)-(5*B6)+(6*B8))*pow(D1,10))/12288));
        W4=(0.5)*(Cl)*(ka)*(D1-(((1/64)*pow(ka,2))*(7+(5*B2))*pow(E1,2)*pow(D1,3))-((pow(ka,4)*(2544+(1886*B2)-(1294*B4)-(771*B6)+(190*B8)+(37*B10))*pow(D1,11))/393216));
        mvvx=fabs((W1*A4*C4)+(W2*A3*C3)+(W3*A2*C2)+(W4*A1*C1));
        mvvy=fabs((W1*G4*F4)+(W2*G3*F3)+(W3*G2*F2)+(W4*G1*F1));
        }
	else if((*Cwa)==52)//Here we calculate the max induced velocities for 5ft order transitonal water waves
        {
       ka=k*(*ampa)*2;
       B1=cosh(kh);
       B2=cosh(2*kh);
       B4=cosh(4*kh);
       B6=cosh(6*kh);
       B8=cosh(8*kh);
       B10=cosh(10*kh);
       B12=cosh(12*kh);
       F1=sinh(kh);
       F2=sinh(2*kh);
       F3=sinh(3*kh);
       F4=sinh(4*kh);
       F5=sinh(5*kh);
       C1=cosh(kh);
       C2=cosh(2*kh);
       C3=cosh(3*kh);
       C4=cosh(4*kh);
       C5=cosh(5*kh);
       A1=cos(pi);
       A2=cos(2*pi);
       A3=cos(3*pi);
       A4=cos(4*pi);
       A5=cos(5*pi);
       G1=sin(pi/2);
       G2=sin(2*(pi/2));
       G3=sin(3*(pi/2)); 
       G4=sin(4*(pi/2));
       G5=sin(5*(pi/2));
       
       W1=-((pow(ka,4)*k*(197-(1338*pow(B1,2))+(736*pow(B1,6)))*pow(D1,10))/(6144*(2+(3*B2))));
       W2=(3/131072)*pow(ka,3)*k*pow(D1,7)*(2816-(512*B2)+((pow(ka,2)*(697-(2186*B2)-(5498*B4)-(3192*B6)+(367*B8)+(90*B10)+(2*B12))*pow(D1,6))/(8*(2+(3*B2)))));
       W3=(0.5)*pow(ka,2)*k*(((1/3)*pow(D1,4))+((pow(ka,2)*(104-(123*B2)-(306*B4)-(5*B6)+(6*B8))*pow(D1,10))/12288));
       W4=(0.5)*(Cl)*(ka)*(D1-(((1/64)*pow(ka,2))*(7+(5*B2))*pow(E1,2)*pow(D1,3))-((pow(ka,4)*(2544+(1886*B2)-(1294*B4)-(771*B6)+(190*B8)+(37*B10))*pow(D1,11))/393216));
       W5=(5*pow(ka,5)*k*(7664+(6680*B2)+B4-(3119*B6)+(272*B8)-(3*B10))*pow(D1,13))/(1048576*((2+(3*B2))*(1+(4*B2))));
       
       mvvx=fabs((W1*A4*C4)+(W2*A3*C3)+(W3*A2*C2)+(W4*A1*C1)+(W5*A5*C5));
       mvvy=fabs((W1*G4*F4)+(W2*G3*F3)+(W3*G2*F2)+(W4*G1*F1)+(W5*G5*F5));
        }
      else{
        mvvx=0;
        mvvy=0;
      }
      if(in==0)
      {
        fprintf(fp, "H(m),L(m),T(s),f(Hz),P(W),DI(m),Mvx(m/s),Mvy(m/s)\n");
      }
      fprintf(fp, "%.3f,%.3f,%.3f,%.3f,%.3f,%3f,%3f,%3f\n", (*ampa)*2, Lwa, *Twa, f, power, depthoint, mvvx, mvvy);
  fp=NULL;

return 0;
}
