#include <stdio.h>
#include <math.h>

float density(void)

{
FILE *fp;
fp=fopen("pdata.txt","r");
float Temp, Sal, p, rho;
int count=0;
//Data is read from the file that defines the sea temperature, salinity and atmospheric pressure at the site.
while(!feof (fp))
  {
      fscanf(fp, "%f", &Temp);
      fscanf(fp, "%f", &Sal);
      fscanf(fp, "%f", &p);
  }
fclose(fp);
//The equations of state for an isothermal sea column are applied.
double a0=999.842594,a1=0.06793953,a2=-.009095290,a3=.0001001685,a4=-0.000001120083,a5=0.000000006536332,phost=0;

phost=a0+(a1*Temp)+(a2*pow(Temp,2))+(a3*pow(Temp,3))+(a4*pow(Temp,4))+(a5*pow(Temp,5));

double b0=0.82449,b1=-0.0040899,b2=0.000076438,b3=-0.00000082467,b4=0.0000000053875,b=0;
b=b0+(b1*Temp)+(b2*pow(Temp,2))+(b3*pow(Temp,3))+(b4*pow(Temp,4));
double c0=-0.0057246,c1=0.00010227,c2=-0.0000016546,c=0;
c=c0+(c1*Temp)+(c2*pow(Temp,2));
double d=0.00048314, phostp=0;

phostp=phost+(b*Sal)+(c*pow(Sal,1.5))+(d*pow(Sal,2));

double e0=19652.210,e1=148.4206,e2=-2.327105,e3=0.01360477,e4=-0.00005155288,kw=0;
kw=e0+(e1*Temp)+(e2*pow(Temp,2))+(e3*pow(Temp,3))+(e4*pow(Temp,4));
double f0=54.6746,f1=-0.603459,f2=0.01099870,f3=-0.00006167,f=0;
f=f0+(f1*Temp)+(f2*pow(Temp,2))+(f3*pow(Temp,3));
double g0=0.07944,g1=0.016483,g2=-0.00053009,g=0;
g=g0+(g1*Temp)+(g2*pow(Temp,2));
double Kst0=0;


Kst0=kw+(f*Sal)+(g*pow(Sal,1.5));

double h0=3.2399,h1=0.000143713,h2=0.000116092,h3=-0.000000577905,Aw=0;
Aw=h0+(h1*Temp)+(h2*pow(Temp,2))+(h3*pow(Temp,3));
double i0=0.0022838,i1=-0.0000109810,i2=-0.00000160780,j0=0.000191075,Aa1=0;
Aa1=Aw+((i0+(i1*Temp)+(i2*pow(Temp,2)))*Sal)+(j0*pow(Sal,1.5));
double k0=0.0000850935,k1=-0.00000612293,k2=0.000000052787,Bw=0;
Bw=k0+(k1*Temp)+(k2*pow(Temp,2));
double m0=-0.00000099348,m1=0.000000020816,m2=0.00000000091697,Bb1=0;
Bb1=Bw+((m0+(m1*Temp)+(m2*pow(Temp,2)))*Sal);
double Kst0p=0;

Kst0p=Kst0+(Aa1*p)+(Bb1*pow(p,2));

rho=(phostp/(1-(p/Kst0p)));
return rho;
}
