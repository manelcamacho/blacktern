Black tern 0.7c (BKT) is an open source program to calculate the values of the wave velocity field under linear wave theory and 2nd/3rd order stokes wave theory, and 5th order using the results of R.Jensen and Fenton for currents at u=0 (currents will be added at versions>0.7c) the program uses a .txt file with ordered values to read the main wave properties as the amplitude and period. The program then writes the wave field values into several .txt files. The program will produce the output of the velocity components along the water column as also a separate file that contains some data as amplitude, period, frequency, average power per square meter, depth of interaction and the maximum velocities that the waves will induce in the water column.

Each wave component taken from the source text file, will produce an (x,y) output file and one final spectral file with some of the wave propierties for every wave component that has been used; the next files explain how this program is used, its aim, the more probable road map and other useful stuff.

---------------------------------------------------------------------------------------

PDF-FILES

USE: describes broadly its use, installation, how to run the program and how to read the outut as also some plots that can be obtained with using this interfacing with other software.

HOWTO: How to use, how it works, example and possible issues.

SO FAR: The range of theories/depths covered.

FUNCTIONS: Explains how the code is distributed in functions and their functions in a genera manner.

---------------------------------------------------------------------------------------

Input-output: describes how to enter the wave data and the output we will have.

Installation: describes the installation process.

Theory: Gives links to the wave theory documents ad some books consulted for this.

Input-output: Describes how the input works and also its output.

Road-map: Describes the steps to implement version from 0.1 to 1.1.

Future-map: steps to be taken to improve the code. 

Aim of the code: Describes what is the purpose fo the code.

To-come: small fixtures that will be added.

License: the GPL license of the code!, the logo is Creative Commons too BTW, based partially on the public domain work made by Robert W. Hines for the US Fish and Wildlife Service <3!.




