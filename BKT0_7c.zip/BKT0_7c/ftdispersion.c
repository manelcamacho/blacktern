#include <stdio.h>
#include <math.h>

float ftdispersion(float *Twa, float *g, float *ampa, float *pi, float *h, float *Lwa2, float *Lw)
{
  float w=0, phi=0, k=0, kt=0, dif=0, s=0, c=0, bet=0, gam=0, ep=0;
	w=(2*(*pi))/(*Twa);
	k=(2*(*pi))/(*Lwa2);
	phi=tanh((k)*(*h));
	s=sinh(k*(*h));
	c=cosh(k*(*h));
	bet=(((8*pow(c,4))-(8*pow(c,2))+9)/(8*pow(s,4)));
	gam=(((3840*pow(c,12))-(4096*pow(c,10))+(2592*pow(c,8))-(1008*pow(c,6))+(5944*pow(c,4))-(1830*pow(c,2))+147)/ ((512*pow(s,10))*((6*pow(c,2))-1)));
	ep= (k*(*ampa))/2;
	kt=w/sqrt(((1+(pow(ep,2)*bet)+(pow(ep,4)*gam))*(*g/k)*phi));
	*Lwa2=(2*(*pi))/kt;
	dif=fabs((k-kt)/k)*100;


  return dif;
}