#include <stdio.h>
#include <math.h>
#include <stdlib.h>

//Here we calculate the linear velocities and deep waters
int velocities4xt(float *ampa, float *dx, float *dz, float *dt, float *Twa, float Lwa, float h, int in, float rho, float pi, float *g)
{

  FILE * fp1, * fp2;

  char namex[FILENAME_MAX];
  char namep[FILENAME_MAX];
	double z=0, x=0, t=0, k=0, ratio=0, n=0, ka=0, A1=0,A2=0,A3=0,A4=0,B1=0,B2=0,B4=0,B6=0,B8=0,B10=0,B12=0,C1=0,C2=0,C3=0,C4=0,E1=0,F1=0,F2=0,F3=0,F4=0,G1=0,G2=0,G3=0,G4=0,W1=0,W2=0,W3=0,W4=0, kh=0, Cl=0, B22=0, B31=0,B33=0, B42=0, B44=0, S=0, kx=0;
	double D1=0;
	int lenght=0, i=0, i2=0;
	
	 	  snprintf(namex, sizeof(namex), "%dx4t.txt", in);
	 	  snprintf(namep, sizeof(namep), "%dp4t.txt", in);
	 	  fp1 = fopen(namex, "w");
	 	  fp2 = fopen(namep, "w");
	 
	    lenght=Lwa/(*dx);
	    //We initialize the arrays dimensions to store the information on the wave velocities
	 	float *arrayx = malloc(lenght * sizeof(*arrayx));
	 	if (!arrayx) {
	 		printf("There was a problem with malloc.");
	 		exit(EXIT_FAILURE);
	 	}
	 	float *arrayy = malloc(lenght * sizeof(*arrayy));
	 	if (!arrayy) {
	 		printf("There was a problem with malloc.");
	 		exit(EXIT_FAILURE);
	 	}
	 	float *arrayp = malloc(lenght * sizeof(*arrayp));
	 	if (!arrayp) {
	 		printf("There was a problem with malloc.");
	 		exit(EXIT_FAILURE);
	 	}
	//Constants to be used on the functions to calculate the velocities
	k=(2*pi)/Lwa;
	ratio=Lwa/2;
	ka=k*(*ampa);
	Cl=(Lwa/(*Twa));
	kh=k*h;
	B1=cosh(kh);
	B2=cosh(2*kh);
	B4=cosh(4*kh);
	B6=cosh(6*kh);
	B8=cosh(8*kh);
	B10=cosh(10*kh);
	B12=cosh(12*kh);
	D1=(1/sinh(kh));
	E1=(1/tanh(kh));
	S=(1/cosh(kh));
	
	B22=(1/tanh(kh))*((1+(2*S))/(2*(1-S)));
	B33= (-3*(1+(3*S)+(3*pow(S,2))+(2*pow(S,3))))/(8*pow((1-S),3));
	B42=(1/tanh(kh))*((6-(26*S)-(182*pow(S,2))-(204*pow(S,3))-(25*pow(S,4))+(26*pow(S,5)))/(6*(3+(2*S))*pow((1-S),4)));
	B44=(1/tanh(kh))*((24+(92*S)-(122*pow(S,2))-(66*pow(S,3))-(67*pow(S,4))+(34*pow(S,5)))/(24*(3+(2*S))*pow((1-S),4)));



	while(x<Lwa){
	  fprintf(fp1, "Vx(%d),Vy(%d),",i,i);
	  fprintf(fp2, "P(%d),", i);
	  i++;
	 x=x+(*dx);
	}
	fprintf(fp1, "\n");
	fprintf(fp2, "\n");
	x=0;
	i=0;



	  //We start to calculate the velocities from t0 to tn=wave period
		while(t<(*Twa))
			{
			  
			  //We calculate the velocity from the mean water level z to the depth of propaation h
				while(z<h)
					{
						F1=sinh(k*(h-z));
						F2=sinh(2*k*(h-z));
						F3=sinh(3*k*(h-z));
						F4=sinh(4*k*(h-z));
						C1=cosh(k*(h-z));
						C2=cosh(2*k*(h-z));
						C3=cosh(3*k*(h-z));
						C4=cosh(4*k*(h-z));

					  i=0;
					  //We calculate the velocity from the position x=0 to a xn=waves wavelenght
						while (x<Lwa)
							{
								A1=cos(k*((-Cl*t)+x));
								A2=cos(2*k*((-Cl*t)+x));
								A3=cos(3*k*((-Cl*t)+x));
								A4=cos(4*k*((-Cl*t)+x));
								G1=sin(k*((-Cl*t)+x));
								G2=sin(2*k*((-Cl*t)+x));
								G3=sin(3*k*((-Cl*t)+x));
								G4=sin(4*k*((-Cl*t)+x));
								kx=k*x;
								
								//List of operations as divided to minimise operationn on the (lenght, depth and time directions).
								W1=-((pow(ka,4)*k*(197-(1338*pow(B1,2))+(736*pow(B1,6)))*pow(D1,10))/(6144*(2+(3*B2))));
								W2=(3/131072)*pow(ka,3)*k*pow(D1,7)*(2816-(512*B2)+((pow(ka,2)*(697-(2186*B2)-(5498*B4)-(3192*B6)+(367*B8)+(90*B10)+(2*B12))*pow(D1,6))/(8*(2+(3*B2)))));
								W3=(0.5)*pow(ka,2)*k*(((1/3)*pow(D1,4))+((pow(ka,2)*(104-(123*B2)-(306*B4)-(5*B6)+(6*B8))*pow(D1,10))/12288));
								W4=(0.5)*(Cl)*(ka)*(D1-(((1/64)*pow(ka,2))*(7+(5*B2))*pow(E1,2)*pow(D1,3))-((pow(ka,4)*(2544+(1886*B2)-(1294*B4)-(771*B6)+(190*B8)+(37*B10))*pow(D1,11))/393216));
								
									//if the wave field reaches the bottom at the continental shelf its velocity its calculated
									arrayx[i]=(W1*A4*C4)+(W2*A3*C3)+(W3*A2*C2)+(W4*A1*C1);
									//By symetric propierties over the field components <3
									arrayy[i]=(W1*G4*F4)+(W2*G3*F3)+(W3*G2*F2)+(W4*G1*F1);
									//The pressure field is then given as the power expansion
									printf("%f %f %f\n\n\n", g, rho, z);
									n=rho*(*g)*(z+((1/k)*((k*h)+((ka/2)*cos(kx))+(pow((ka/2),2)*cos(2*kx)*B22)+(pow((ka/2),3)*(cos(kx)-cos(3*kx))*B31)+(pow((ka/2),4)*((B42*cos(2*kx))+(B44*cos(4*kx)))))));
									arrayp[i]=n;
								  
								  i++;
								  x=x+(*dx);
								}
								while(i2<i){
								  //We store the whole data from the arrays to a file
								  fprintf(fp1, "%.3f,%.3f,",arrayx[i2],arrayy[i2]);
								  fprintf(fp2, "%.3f,", arrayp[i2]);
								  i2++;
								}
								fprintf(fp1, "\n");
								fprintf(fp2, "\n");
						i2=0;
						x=0;
						z=z+(*dz);
					}
					fprintf(fp1, "\n\n");
					fprintf(fp2, "\n\n");
					z=0;
					t=t+(*dt);
			}
			  fp1=NULL;
			  fp2=NULL;
			  fclose(fp1);
			  fclose(fp2);
			  in++;


		return 0;
}
