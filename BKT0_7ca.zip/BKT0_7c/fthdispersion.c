#include <stdio.h>
#include <math.h>

float fthdispersion(float *Twa, float *g, float *ampa, float *pi, float *h, float *Lwa2, float *Lw)
{
  float w=0, k=0, kt=0, dif=0, s=0, c=0, ep=0, c4=0,c2=0;
	w=(2*(*pi))/(*Twa);
	k=(2*(*pi))/(*Lwa2);
	s=(1/cosh(2*k*(*h)));
	ep=(k*(*ampa))/2;
	c=sqrt(tanh(k*(*h)));
	c2=(c*(2+(7*pow(s,2)))/(4*(1-pow(s,2))));
	c4= (c*(4+(32*s)-(116*pow(s,2))-(400*pow(s,3))-(71*pow(s,4))+(146*pow(s,5)))/(32*(1-pow(s,5))));
	kt=(w/(sqrt(*g/k)*(c+(c2*pow(ep,2))+(c4*pow(ep,4)))));
	*Lwa2=(2*(*pi))/kt;
	dif=fabs((k-kt)/k)*100;

  return dif;
}