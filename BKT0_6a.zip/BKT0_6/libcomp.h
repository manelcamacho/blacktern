void spaces (float nt, float *sp, float *sp1, float *sp2, float *sp3, float *sp4, float *sp5);
float typeofwave(float Lw, float h);
