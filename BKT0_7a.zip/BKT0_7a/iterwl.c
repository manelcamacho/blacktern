#include<stdio.h>
#include<math.h>

float iterwl(float *Lw, float *Twa, float *pi, float *h, float *Lwa2)

{
  float dif=0;
  *Lw=1.56*pow(*Twa,2)*tanh((2*(*pi)*(*h))/(*Lwa2));
  *Lwa2=*Lw;
  dif=fabs((*Lwa2-*Lw)/(*Lwa2))*100;

return dif;
}
