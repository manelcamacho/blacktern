float pl_gravity(float lat);
float wavelenght(float *Twa, float h, float gloc, float pi);
int spectral(float *ampa, float *Twa, float Lwa, float h, int in, float lat, float *Cwa, float pi, float rho);
float density(void);
float iterwl(float *Lw, float *Twa, float *pi, float *h, float *Lwa2);
float lindispersion(float *Twa, float *g, float *ampa, float *Cwa, float *pi);
float trdispersion(float *Twa, float *g, float *ampa, float *pi, float *h, float *Lwa2, float *Lw);
