#include <stdio.h>
#include <math.h>

void nond(float *nt1, float *nt2, float *nd, float g, float *Twa, float *ampa, int i)
{
  *nt1=(*nd/(g*pow(*Twa,2)));
  *nt2=((*ampa)/(g*pow(*Twa,2)));

}
