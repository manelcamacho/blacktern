int velocitiesxd(float *ampa, float *dx, float *dz, float *dt, float *Twa, float Lwa, float h, int in, float rho, float pi, float *g);
int velocitiesxt(float *ampa, float *dx, float *dz, float *dt, float *Twa, float Lwa, float h, int in, float rho, float pi, float *g);
int velocities2xd(float *ampa, float *dx, float *dz, float *dt, float *Twa, float Lwa, float h, int in, float rho, float pi, float *g);
int velocities2xt(float *ampa, float *dx, float *dz, float *dt, float *Twa, float Lwa, float h, int in, float rho, float pi, float *g);
int velocities3xd(float *ampa, float *dx, float *dz, float *dt, float *Twa, float Lwa, float h, int in, float rho, float pi, float *g);
int velocities3xt(float *ampa, float *dx, float *dz, float *dt, float *Twa, float Lwa, float h, int in, float rho, float pi, float *g);
