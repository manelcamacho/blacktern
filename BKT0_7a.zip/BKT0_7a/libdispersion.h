float lindispersion(float *Twa, float *g, float *ampa+, float *Cwa, float *pi);
