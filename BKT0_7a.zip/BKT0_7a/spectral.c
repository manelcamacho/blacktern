#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "libprop.h"


int spectral(float *ampa, float *Twa, float Lwa, float h, int in, float lat, float *Cwa, float pi, float rho)
{
  FILE * fp;
  char name[FILENAME_MAX];
    float g=0, power=0, depthoint=0, mvvx=0, mvvy=0, a0=0, f=0, k=0, w=0;
      fp = fopen("spectral.txt", "a");
      if(fp == NULL)
   {
      printf("Error could not open or create file!");
      exit(1);
   }
      g=pl_gravity(lat);
      f=(1/(*Twa));
      *ampa=*ampa/2;
      power=((rho*g)/2)*(*ampa)*(*ampa);
      depthoint=Lwa/2;
      a0=(*ampa*2*pi)/(*Twa);
      k=(2*pi)/Lwa;

      if((*Cwa)==11)
      {
        mvvx=a0;
        mvvy=a0;
      }
      else if((*Cwa)==12)
      {
        mvvx=fabs(a0*(cosh(k*(-h)))/sinh(k*h));
        mvvy=fabs(a0*(sinh(k*(-h)))/sinh(k*h));
      }
      else if((*Cwa)==21)
      {

        mvvx=  fabs((-a0/4)*(1/sinh(k*h))*((4*cosh(k*(-h))) + ((3*(*ampa)*k*(cosh(2*k*(-h))))*(pow(1/sinh(k*h),3)))));
        mvvy=  fabs((-a0/4)*(1/sinh(k*h))*((4*sinh(k*(-h))) + ((3*(*ampa)*k*(sinh(2*k*(-h))))*(pow(1/sinh(k*h),3)))));
      }
      else if((*Cwa)==22)
      {
        mvvx=fabs((-a0*cosh(k*(-h))*(1/sinh(k*h))));
        mvvy=fabs((-a0*sinh(k*(-h))*(1/sinh(k*h))));
      }
      else if((*Cwa)==31)
      {
        mvvx=(*ampa)*sqrt(g/k);
        mvvy=(*ampa)*sqrt(g/k);
      }
      else if((*Cwa)==32)
      {
        w=(2*pi)/f;
        mvvx=fabs(((((*ampa)*w)/64)*(1/sinh(h*k)))*((64*cosh(k*(-h)))+(((3*(*ampa)*k)*(1/(sinh(k*h)*sinh(k*h)*sinh(k*h)))) *((16*cosh(2*k*(-h)))+((*ampa*k*cosh(3*k*(-h)))*(1/sinh(k*h))*((9*(1/(sinh(h*k)*sinh(h*k))))-4))))));
        mvvy=fabs(((((*ampa)*w)/64)*(1/sinh(h*k)))*((64*sinh(k*(-h)))+(((3*(*ampa)*k)*(1/(sinh(k*h)*sinh(k*h)*sinh(k*h)))) *((16*sinh(2*k*(-h)))+((*ampa*k*sinh(3*k*(-h)))*(1/sinh(k*h))*((9*(1/(sinh(h*k)*sinh(h*k))))-4))))));
      }
      else{
        mvvx=0;
        mvvy=0;
      }
      if(in==0)
      {
        fprintf(fp, "H(m),L(m),T(s),f(Hz),P(W),DI(m),Mvx(m/s),Mvy(m/s)\n");
      }
      fprintf(fp, "%.3f,%.3f,%.3f,%.3f,%.3f,%3f,%3f,%3f\n", *ampa, Lwa, *Twa, f, power, depthoint, mvvx, mvvy);
  fp=NULL;

return 0;
}
