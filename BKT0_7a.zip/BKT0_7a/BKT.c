#include<stdio.h>
#include<string.h>
#include<math.h>
#include<unistd.h>
#include<stdlib.h>
#define BUFSIZE 1000

//made libraries
#include "libdata.h"
#include "libprop.h"
#include "libcomp.h"
#include "libfields.h"


float pi=3.14159;
float conv=1;

int main(int argc, char* argv[])
{
float nd[2], g=0;
int t=0, i=0;

//we read the size of the data file to store infromation on the arrays
t=read_ints();
t=t/5;

//Here we create  the dynamic arrays to store the values from the data file
float *Twa = malloc(t * sizeof(*Twa));
if (!Twa) {
    printf("There was a problem with malloc.");
    exit(EXIT_FAILURE);
}
float *ampa = malloc(t * sizeof(*ampa));
if (!ampa) {
    printf("There was a problem with malloc.");
    exit(EXIT_FAILURE);
}

float *dx = malloc(t * sizeof(*dx));
if (!dx) {
    printf("There was a problem with malloc.");
    exit(EXIT_FAILURE);
}

float *dz = malloc(t * sizeof(*dz));
if (!dz) {
    printf("There was a problem with malloc.");
    exit(EXIT_FAILURE);
}

float *dt = malloc(t * sizeof(*dt));
if (!dt) {
    printf("There was a problem with malloc.");
    exit(EXIT_FAILURE);
}

float *Cwa = malloc(t * sizeof(*Cwa));
if (!Cwa) {
    printf("There was a problem with malloc.");
    exit(EXIT_FAILURE);
}

//Here we store the data from the file to each array as it corresponds
FILE *fpa = fopen(argv[1], "r"); /* "r" = open for reading */
char buff[BUFSIZE]; /* a buffer to hold what you read in */

int count=1, ip=0, ia=0, ix=0, iz=0, it=0, condit=1;
float kn=0;

while(!feof (fpa))
  {
    if(condit==0)
    {
      count=1;
      condit=1;
    }

    if (count==1)
    {
      fscanf(fpa, "%f", &Twa[ip]);


      ip++;
    }
    else if (count==2)
    {
      fscanf(fpa, "%f", &ampa[ia]);


      ia++;
    }

    else if (count==3)
    {
      fscanf(fpa, "%f", &dx[ix]);

      ix++;
    }

    else if (count==4)
    {
      fscanf(fpa, "%f", &dz[iz]);

      iz++;
    }

    else if (count==5)
    {
      fscanf(fpa, "%f", &dt[it]);

      it++;
      condit=0;
    }
    count++;



  }
fclose(fpa);


ia=0;
//Here we read the values of the depth and latitude that will be used for the gravitation and nondimensaional calculations
read_nd(nd);
//Here we calculate the gravity at the given latitute
g=pl_gravity(nd[1]);

float nt[2], Lwa2, Lw, dif, rho=0;
//We start to calculate the wave velocities from i=0 to the maxi size of file i<t where t=n the maximum number of wave omponents on the file
while (i<t)
{
  //Here we calculate the non-dimensional propierties to use the respective wave theory
nond( nt, nt+1, nd, g, Twa+i, ampa+i, i);
float sp[6];
//Here we compare the spaces at which the wave belongs to
spaces(nt[0], sp, sp+1, sp+2, sp+3, sp+4, sp+5);

//Here we calculate the deep water wavelenght using the dean relaitionshop with good accuracy for waves in crrents that are at maximum 10% of the wave celerity
Lwa2=wavelenght(Twa+i, nd[0], g, pi);
//Now we calculate if we have a deep water wave or tranasitional water wave depending on the wavelenght to depth ratio
Cwa[i]=typeofwave(Lwa2, nd[0]);
rho=density();

if(nt[0]<0.1){
/*Here we compare our non dimensional values to confirm if we have a linear wave*/
  if(sp[0]>=nt[1])
  {

      //Here we calculate the velocities of the wave components if they are linear and occur in deep waters
      if (Cwa[i]==1) {
        Cwa[i]=11;
        Lwa2=lindispersion(Twa+i,&g,ampa+i,Cwa+i,&pi);

        velocitiesxd(ampa+i, dx+i, dz+i, dt+i, Twa+i, Lwa2, nd[0], i, rho, pi, &g);

      }
        //Here we calculate the velocities of the wave components if they are linear and occur in transitional waters
      else if (Cwa[i]==3) {
        dif=5;
        Cwa[i]=12;
        Lwa2=lindispersion(Twa+i,&g,ampa+i,Cwa+i,&pi);
        while(dif>.01)
        {
          dif=iterwl(&Lw, Twa+i, &pi, nd, &Lwa2);
        }
        kn=(2*pi)/Lwa2;
        velocitiesxt(ampa+i, dx+i, dz+i, dt+i, Twa+i, Lwa2, nd[0], i, rho, pi, &g);

      }
      else {
        printf("No wave recognized\n" );
      }

  }
  /*In this part we compare to see if the wave is second order or cnoidal*/


  else if (sp[0]<nt[1]&&sp[1]>nt[1]) {
      /*we compare the slope that divides the cnoidal theory from the second order theory*/
      if (sp[3]>nt[1]) {
          //Here we calculate the velocities of the wave components if they are second order and occur in deep waters
        if ( Cwa[i]==1)
        {
          Cwa[i]=21;
          Lwa2=lindispersion(Twa+i,&g,ampa+i,Cwa+i,&pi);
          kn=(2*pi)/Lwa2;
          velocities2xd(ampa+i, dx+i, dz+i, dt+i, Twa+i, Lwa2, nd[0], i, rho, pi, &g);

          }
            //Here we calculate the velocities of the wave components if they are linear and occur in transitional waters
          else if (Cwa[i]==3)
          {
            Cwa[i]=21;
            dif=10;
            Lwa2=lindispersion(Twa+i,&g,ampa+i,Cwa+i,&pi);
            while(dif>.1)
            {
            dif=trdispersion( Twa+i, &g, ampa+i, &pi, nd, &Lwa2, &Lw);
            }
            kn=(2*pi)/Lwa2;
            velocities2xt(ampa+i, dx+i, dz+i, dt+i, Twa+i, Lwa2, nd[0], i, rho, pi, &g);
            Cwa[i]=22;

          }

      }
      else if (sp[3]<=nt[1]) {
        /* code */printf("The wave is a cnoidal wave\n");
        Cwa[i]=6;
      }

  }

  /*Here we search for a 5th, 4th or 3rd order wave*/
  else if (sp[1]<nt[1]&&sp[2]>nt[1]) {
    /*Here we compare for a 5th order wave*/
    if (sp[3]<nt[1]){
      printf("You have a 5th order wave\n" );
      Cwa[i]=5;
    }
      /*Here we compare for a 4th or 3rd order wave*/
    else if (sp[3]>nt[1]) {
      if (sp[5]>=nt[1]){

        if ( Cwa[i]==1)
        {

          Cwa[i]=31;
          Lwa2=lindispersion(Twa+i,&g,ampa+i,Cwa+i,&pi);
          kn=(2*pi)/Lwa2;
          velocities3xd(ampa+i, dx+i, dz+i, dt+i, Twa+i, Lwa2, nd[0], i, rho, pi, &g);

          }
            //Here we calculate the velocities of the wave components if they are linear and occur in transitional waters
          else if (Cwa[i]==3)
          {

            Cwa[i]=31;
            dif=10;
            Lwa2=lindispersion(Twa+i,&g,ampa+i,Cwa+i,&pi);
            while(dif>.01)
            {
            dif=trdispersion( Twa+i, &g, ampa+i, &pi, nd, &Lwa2, &Lw);
            }
            kn=(2*pi)/Lwa2;
            velocities3xt(ampa+i, dx+i, dz+i, dt+i, Twa+i, Lwa2, nd[0], i, rho, pi, &g);
            Cwa[i]=32;
          }

      }
      else if (sp[5]<nt[1]) {
        printf("You have a fourth order wave\n" );
        Cwa[i]=4;
      }
    }
  }
    else
    {

      printf("You have shallow waters waves or breaking conditions\n" );
      Cwa[i]=0;
    }

  }
//Here we compare to all theories at deep waters at non dimensional depths larger than 0.1 then only using the nondimensional depth and the y axis coordinates
  else if(nt[0]>=0.1)
  {
      //Here we calculate the velocities of the wave components if they are linear and occur in deep waters
    if(nt[1]<0.001)
    {
      Cwa[i]=11;
      Lwa2=lindispersion(Twa+i,&g,ampa+i,Cwa+i,&pi);
      kn=(2*pi)/Lwa2;
      velocitiesxd(ampa+i, dx+i, dz+i, dt+i, Twa+i, Lwa2, nd[0], i, rho, pi, &g);
      Cwa[i]=11;

    }
      //Here we calculate the velocities of the wave components if they are second order or at higher order in stream theory and occur in deep waters
    else if(0.001<=nt[1]&&nt[1]<0.0073)
    {
      Cwa[i]=21;
      Lwa2=lindispersion(Twa+i,&g,ampa+i,Cwa+i,&pi);
      kn=(2*pi)/Lwa2;
      velocities2xd(ampa+i, dx+i, dz+i, dt+i, Twa+i, Lwa2, nd[0], i, rho, pi, &g);
      Cwa[i]=21;
    }
    else if(0.0073<=nt[1]&&nt[1]<0.0088)
    {
    /* code */printf("The wave is a 5th order order wave\n");
    Cwa[i]=5;
    }
      //Here we calculate the velocities of the wave components if they are linear and occur in deep waters
    else if(0.0088<=nt[1]&&nt[1]<0.0198)
    {
      Cwa[i]=31;
      dif=10;
      Lwa2=lindispersion(Twa+i,&g,ampa+i,Cwa+i,&pi);
        while(dif>0.01)
        {
          dif=trdispersion( Twa+i, &g, ampa+i, &pi, nd, &Lwa2, &Lw);
        }
        kn=(2*pi)/Lwa2;
      velocities3xd(ampa+i, dx+i, dz+i, dt+i, Twa+i, Lwa2, nd[0], i, rho, pi, &g);
    }
    else if(0.0198<=nt[1]&&nt[1]<0.0285)
    {
    /* code */printf("The wave is a 4th order order wave\n");
    Cwa[i]=4;
    }
    else{
      /* code */printf("breaking wave or not recognize pattern\n");
      Cwa[i]=0;
    }

  }
i++;
}


i=0;

  while(i<t)
  {
    if(Cwa[i]==11)
    {
      Lwa2=wavelenght(Twa+i, nd[0], g, pi);
    }
    else if (Cwa[i]==12)
    {
      dif=5;
      Lwa2=lindispersion(Twa+i,&g,ampa+i,Cwa+i,&pi);
      while(dif>.01)
      {
        dif=iterwl(&Lw, Twa+i, &pi, nd, &Lwa2);
      }
    }
    else if (Cwa[i]==21)
    {
      Lwa2=lindispersion(Twa+i,&g,ampa+i,Cwa+i,&pi);
    }
    else if (Cwa[i]==22)
    {
      Cwa[i]=21;
      dif=10;
      Lwa2=lindispersion(Twa+i,&g,ampa+i,Cwa+i,&pi);
      while(dif>.01)
      {
      dif=trdispersion( Twa+i, &g, ampa+i, &pi, nd, &Lwa2, &Lw);
      }
      Cwa[i]=22;
    }
    else if (Cwa[i]==31)
    {
      Lwa2=lindispersion(Twa+i,&g,ampa+i,Cwa+i,&pi);
    }
    else if (Cwa[i]==32)
    {
      Cwa[i]=31;
      dif=10;
      Lwa2=lindispersion(Twa+i,&g,ampa+i,Cwa+i,&pi);
      while(dif>.01)
      {
      dif=trdispersion( Twa+i, &g, ampa+i, &pi, nd, &Lwa2, &Lw);
      }
      Cwa[i]=32;
    }
    spectral(ampa+i, Twa+i, Lwa2, nd[0], i, nd[1], Cwa+i, pi, rho);
    i++;
  }


return 0;
}
