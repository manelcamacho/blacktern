#include <stdio.h>
#include <math.h>

float lindispersion(float *Twa, float *g, float *ampa, float *Cwa, float *pi)
{
  float Wl=0, Wli=0, Wavel=0, dif=10,k=0, kb=0;

  Wl=(*g/(2*(*pi)))*(*Twa)*(*Twa);

  if (*Cwa==11|*Cwa==12)
  {
    Wavel=Wl;
  }

  else if (*Cwa==21|*Cwa==31)
  {
    while (dif>=.1)
    {
      kb=(2*(*pi))/(Wl);
      k=pow((((2*(*pi))/(*Twa))/((1+((0.5)*pow((((2*(*pi))/(Wl))*(*ampa)),2)))*sqrt(*g))),2);
      dif=fabs(((k-kb)/kb)*100);
      Wl=(2*(*pi))/(k);
    }
    Wavel=Wl;
  }

  return Wavel;
}
