#include <stdio.h>
#include <math.h>

float trdispersion(float *Twa, float *g, float *ampa, float *pi, float *h, float *Lwa2, float *Lw)
{
  float w=0, phi=0, k=0, kt=0, dif=0;
    w=(2*(*pi))/(*Twa);
    k=(2*(*pi))/(*Lwa2);
    phi=tanh((k)*(*h));
    kt=pow((w/((1+(pow((*ampa)*(k),2)*((9-(10*(pow(phi,2)))+(9*(pow(phi,4))))/(16*(pow(phi,4))))))*sqrt(*g))),2);
    *Lwa2=(2*(*pi))/kt;
    dif=fabs((k-kt)/k)*100;
    

  return dif;
}
