int read_ints(void);
void read_nd(float *nd);
void nond(float *nt1, float *nt2, float *nd, float g, float *Twa, float *ampa, int i);
