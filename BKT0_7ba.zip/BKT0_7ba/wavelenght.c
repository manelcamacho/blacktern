#include<stdio.h>
#include<math.h>

float wavelenght(float *Twa, float h, float gloc, float pi)

{
    float wavelenghtval=0;
    //We calculate the wavelenght of the wave
    wavelenghtval=((gloc*pow(*Twa,2))/(2*pi))* pow( tanh( pow((2*pi)*((sqrt(h/gloc))/(*Twa)),(3/2)) ), (2/3) );
    return wavelenghtval;

}
