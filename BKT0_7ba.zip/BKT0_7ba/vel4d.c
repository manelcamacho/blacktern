#include <stdio.h>
#include <math.h>
#include <stdlib.h>

//Here we calculate the linear velocities and deep waters
int velocities4xd(float *ampa, float *dx, float *dz, float *dt, float *Twa, float Lwa, float h, int in, float rho, float pi, float *g)
{

  FILE * fp1, * fp2;

  char namex[FILENAME_MAX];
  char namep[FILENAME_MAX];
	float z=0, x=0, t=0, k=0, tpi=0, a0=0, a2=0, ep1=0, ep2=0, ep3=0, arg=0, kons=0, ratio=0, n=0, ka=0, p1=0, p2=0, p3=0, b1=0,b2=0,b3=0,b4=0, el1=0, el2=0, kx=0;
	int lenght=0, i=0, i2=0;
	  snprintf(namex, sizeof(namex), "%dx4.txt", in);
	  snprintf(namep, sizeof(namep), "%dp4.txt", in);
	  fp1 = fopen(namex, "w");
	  fp2 = fopen(namep, "w");
	  printf("HALLO\n");

   lenght=Lwa/(*dx);
   //We initialize the arrays dimensions to store the information on the wave velocities
	float *arrayx = malloc(lenght * sizeof(*arrayx));
	if (!arrayx) {
		printf("There was a problem with malloc.");
		exit(EXIT_FAILURE);
	}
	float *arrayy = malloc(lenght * sizeof(*arrayy));
	if (!arrayy) {
		printf("There was a problem with malloc.");
		exit(EXIT_FAILURE);
	}
	float *arrayp = malloc(lenght * sizeof(*arrayp));
	if (!arrayp) {
		printf("There was a problem with malloc.");
		exit(EXIT_FAILURE);
	}
	//Constants to be used on the functions to calculate the velocities
	*ampa=*ampa/2;
	tpi=2*pi;
	a0=((tpi*(*ampa))/(*Twa));
	k=(tpi)/Lwa;
	ratio=Lwa/2;
	ka=k*(*ampa);
	kons=sqrt((*g)/k);
	ep1=-(Lwa/(*Twa));
	ep2=(-8-(4*pow(ka,2))-(pow(ka,4)));
	ep3=(2-pow(ka,2));


	while(x<Lwa){
	  fprintf(fp1, "Vx(%d),Vy(%d),",i,i);
	  fprintf(fp2, "P(%d),", i);
	  i++;
	 x=x+(*dx);
	}
	fprintf(fp1, "\n");
	fprintf(fp2, "\n");
	x=0;
	i=0;



	  //We start to calculate the velocities from t0 to tn=wave period
		while(t<(*Twa))
			{
				
			  a2=(t/(*Twa));
			  //We calculate the velocity from the mean water level z to the depth of propaation h
				while(z<h)
					{
						
					  b1=(-4*exp(-k*z))*ka*(-2+pow(ka,2));
					  b2=(8*exp(-k*2*z)*pow(ka,4));
					  b3=(exp(-k*z)*ka);
					  b4=((4*exp(-k*z))*pow(ka,3));
					  i=0;
					  //We calculate the velocity from the position x=0 to a xn=waves wavelenght
						while (x<Lwa)
							{
								el1=cos(-k*x);
								el2=cos(-k*x*2);
								  if (z>ratio)
								  {
									//If the wave does not reach the bottom then its velocity field is 0
									arrayx[i]=0;
									arrayy[i]=0;
									arg=tpi*( -(x/Lwa) +a2 );
									n=rho*(*g)*(z+((1/k)*(((ka/2)*cos(kx))+(pow((ka/2),2)*cos(2*kx)*(1/2))+(pow((ka/2),3)*(cos(3*kx)-cos(kx))*(3/8))+(pow((ka/2),4)*(1/3)*(cos(2*kx)+cos(4*kx))))));
									arrayp[i]=n;


								  }
								else
								  {
									//if the wave field reach the bottom its velocity its calculated
									arg=tpi*( -(x/Lwa) +a2 );
									arrayx[i]=ep1-((kons/8)*(ep2+(b1*cos(arg))+(b2*cos(2*arg))));
									arrayy[i]=(kons/2)*b3*(ep3+(b4*cos(arg)))*sin(arg);
									n=rho*(*g)*(z+((1/k)*(((ka/2)*cos(kx))+(pow((ka/2),2)*cos(2*kx)*(1/2))+(pow((ka/2),3)*(cos(3*kx)-cos(kx))*(3/8))+(pow((ka/2),4)*(1/3)*(cos(2*kx)+cos(4*kx))))));
									arrayp[i]=n;
								  }
								  i++;
								  x=x+(*dx);
								 
								}
								while(i2<i){
								  //We store the whole data from the arrays to a file
								  fprintf(fp1, "%.3f,%.3f,",arrayx[i2],arrayy[i2]);
								  fprintf(fp2, "%.3f,", arrayp[i2]);
								  i2++;
								}
								fprintf(fp1, "\n");
								fprintf(fp2, "\n");
						i2=0;
						x=0;
						z=z+(*dz);
					}
					fprintf(fp1, "\n\n");
					fprintf(fp2, "\n\n");
					z=0;
					t=t+(*dt);
			}
			  fp1=NULL;
			  fp2=NULL;
			  fclose(fp1);
			  fclose(fp2);
			  in++;


		return 0;
}
