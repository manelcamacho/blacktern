#include <stdio.h>
#include <math.h>

void spaces (float nt, float *sp, float *sp1, float *sp2, float *sp3, float *sp4, float *sp5)
{
/*Here we set the functions that define each range of te wave theories starting from lineal, second order, and fifth*/
/*This is the function that divides the Airy space-second stokes space*/
*sp=0.0000322962 - (0.00200355 *(pow(nt,(0.25)))) + (0.0111283 *pow(nt,0.5)) - (0.0136872*nt);

/*This is the function that divides the Kortewegg de Vries space-second stokes and Fifth-Third stokes space*/
*sp1=(0.00124726 - (0.0244293*pow(nt,0.25)) + (0.0988321*pow(nt,0.5)) - (0.10934*nt));

/*This is the function that divides Fifth-Forth-Third stokes space to breaking waves*/
*sp2=(0.00472213  - (0.0966994*pow(nt,0.25)) + (0.390791*pow(nt,0.5)) - (0.432903*nt));

/*This is the function that divides the Kortewegg de Vries space from second order and the Stokes-Kortewegg de Vries with 3rd and 4th order*/
*sp3=(-0.0262843 + (0.2938879*pow(nt,0.25)) - (0.92127 *pow(nt,0.5)) + (2.77775*nt));

/*This is the function that divides the Third-stream-fifth stokes spaces*/
*sp4=(-0.0242947 + (0.114039*pow(nt,0.25)) - (0.0975339*pow(nt,0.5)) + (0.00202345*nt));

/*This is the function that divides the Third-Forth stokes spaces*/
*sp5=(-0.122536 + (0.608611*pow(nt,0.25)) - (0.725805 *pow(nt,0.5)) + (0.299734*nt));


}
