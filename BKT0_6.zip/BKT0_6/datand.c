#include <stdio.h>

void read_nd(float *nd)
{
printf("Introduce the depth were the waves propagate: ");
scanf("%f", nd);
printf("\n");
printf("Introduce the latitude of the buoy: ");
scanf("%f", nd+1);
}
