#include <stdio.h>

int read_ints(void)
{
  FILE *fp;
  fp=fopen("data.txt", "r");
  float i = 0, count=1;

  fscanf(fp, "%f", &i);
  while(!feof (fp))
    {
      fscanf(fp, "%f", &i);
      count++;
    }
  fclose(fp);

  return count;
}
