#include <stdio.h>
#include <math.h>
#include <stdlib.h>

//Here we calculate the 2nd order velocities at deep waters
int velocities2xd(float *ampa, float *dx, float *dz, float *dt, float *Twa, float Lwa, float h, int in, float rho, float pi)
{

  FILE * fp1, * fp2;

  char namex[FILENAME_MAX];
  char namep[FILENAME_MAX];
    float z=0, x=0, t=0, k=0, tpi=0, a0=0, a1=0, a2=0, arg=0, kons=0, kons1x=0, kons1y=0, ratio=0, hk=0, nam=0, g=9.81;
    int lenght=0, i=0, i2=0, n=0;
    printf("You have a 2nd order depp water wave\n");
    snprintf(namex, sizeof(namex), "%dx2.txt", in);
    snprintf(namep, sizeof(namep), "%dp2.txt", in);
    fp1 = fopen(namex, "w");
    fp2 = fopen(namep, "w");

   lenght=Lwa/(*dx);
   //We initialize the arrays dimensions to store the information on the wave velocities
    float *arrayx = malloc(lenght * sizeof(*arrayx));
    if (!arrayx) {
        printf("There was a problem with malloc.");
        exit(EXIT_FAILURE);
    }
    float *arrayy = malloc(lenght * sizeof(*arrayy));
    if (!arrayy) {
        printf("There was a problem with malloc.");
        exit(EXIT_FAILURE);
    }
    float *arrayp = malloc(lenght * sizeof(*arrayp));
    if (!arrayp) {
        printf("There was a problem with malloc.");
        exit(EXIT_FAILURE);
    }
    //Constants to be used on the functions to calculate the velocities, 2pi, a*w, wave number, depth and wavenumber, cte a at velocities, wavelenght ratio
    *ampa=*ampa/2;
    tpi=2*pi;
    a0=((tpi*(*ampa))/(*Twa));
    k=(tpi)/Lwa;
    hk=h*k;
    a1=-a0*(1/sinh(hk));
    ratio=Lwa/2;
    nam=tanh(hk);

    while(x<Lwa){
      fprintf(fp1, "Vx(%d),Vy(%d),",i,i);
      fprintf(fp2, "P(%d),", i);
      i++;
     x=x+(*dx);
    }
    fprintf(fp1, "\n");
    fprintf(fp2, "\n");
    x=0;
    i=0;

      //We start to calculate the velocities from t0 to tn=wave period
        while(t<(*Twa))
            {
              a2=(t/(*Twa));
              //We calculate the velocity from the mean water level z to the depth of propaation h
                while(z<h)
                    {
                      kons=k*(-h+z);
                      kons1x=cosh(kons);
                      kons1y=sinh(kons);
                      i=0;
                      //We calculate the velocity from the position x=0 to a xn=waves wavelenght
                        while (x<Lwa)
                            {
                                  if (z>ratio)
                                  {
                                    //If the wave does not reach the bottom then its velocity field is 0
                                    arrayx[i]=0;
                                    arrayy[i]=0;
                                    n=(*ampa)*( (cos(arg)+(((k*(*ampa))*((3-pow(nam,2))/(4*pow(nam,3))))*cos( (2*arg) ))));
                                    arrayp[i]=g*(z+n)*rho;


                                  }
                                else
                                  {
                                    //if the wave field reach the bottom its velocity its calculated
                                    arg=tpi*( -(x/Lwa) +a2 );
                                    arrayx[i]=a1*((cos(arg)*kons1x));
                                    arrayy[i]=a1*((sin(arg)*kons1y));
                                    n=(*ampa)*( (cos(arg)+(((k*(*ampa))*((3-pow(nam,2))/(4*pow(nam,3))))*cos( (2*arg) ))));
                                    arrayp[i]=g*(z+n)*rho;

                                  }
                                  i++;
                                  x=x+(*dx);
                                }
                                while(i2<i){
                                  //We store the whole data from the arrays to a file
                                  fprintf(fp1, "%.3f,%.3f,",arrayx[i2],arrayy[i2]);
                                  fprintf(fp2, "%.3f,", arrayp[i2]);
                                  i2++;
                                }
                                fprintf(fp1, "\n");
                                fprintf(fp2, "\n");
                        i2=0;
                        x=0;
                        z=z+(*dz);
                    }
                    fprintf(fp1, "\n\n");
                    fprintf(fp2, "\n\n");
                    z=0;
                    t=t+(*dt);
            }
              fp1=NULL;
              fp2=NULL;
              in++;


        return 0;
}
