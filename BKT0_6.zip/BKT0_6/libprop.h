float pl_gravity(float lat);
float wavelenght(float *Twa, float h, float gloc, float pi);
int spectral(float *ampa, float *Twa, float Lwa, float h, int in, float lat, float *Cwa, float pi, float rho);
