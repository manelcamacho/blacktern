float typeofwave(float Lw, float h)

{
    float ratio=0, val=0;
    //Here we define if the wave is propagating in deep, transitional or shallow waters
    ratio=Lw/h;

    if (ratio<=2)
    {
        val=1;

    }
    else if (ratio>=20)
    {
        val=2;
    }
    else if (ratio<=20&&ratio>=2)
    {
        val=3;
    }

    return val;
}
